package com.example.kycapp.data.repositories

import android.content.Context
import com.example.kycapp.data.local.SecureKeyStore
import com.example.kycapp.domain.models.Wallet
import com.example.kycapp.domain.models.WalletResult
import com.example.kycapp.service.WalletService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * WalletRepository - Manages wallet operations with local storage
 */
class WalletRepository(context: Context) {
    
    private val walletService = WalletService(context)
    private val secureKeyStore = SecureKeyStore(context)
    
    /**
     * Create new wallet
     */
    suspend fun createWallet(): WalletResult = withContext(Dispatchers.IO) {
        walletService.createWallet()
    }
    
    /**
     * Get wallet by ID
     */
    suspend fun getWallet(walletId: String): Wallet? = withContext(Dispatchers.IO) {
        walletService.getWallet(walletId)
    }
    
    /**
     * Get all wallets
     */
    suspend fun getAllWallets(): List<Wallet> = withContext(Dispatchers.IO) {
        val walletIds = secureKeyStore.getAllWalletIds()
        walletIds.mapNotNull { walletId ->
            walletService.getWallet(walletId)
        }
    }
    
    /**
     * Check if wallet exists
     */
    suspend fun walletExists(walletId: String): Boolean = withContext(Dispatchers.IO) {
        walletService.walletExists(walletId)
    }
    
    /**
     * Delete wallet
     */
    suspend fun deleteWallet(walletId: String): Boolean = withContext(Dispatchers.IO) {
        walletService.deleteWallet(walletId)
    }
    
    /**
     * Update wallet KYC status
     */
    suspend fun updateWalletKycStatus(walletId: String, isCompliant: Boolean): Boolean = withContext(Dispatchers.IO) {
        walletService.updateWalletKycStatus(walletId, isCompliant)
    }
    
    /**
     * Get wallet balance
     */
    suspend fun getWalletBalance(walletId: String): Double = withContext(Dispatchers.IO) {
        walletService.getWalletBalance(walletId)
    }
    
    /**
     * Validate wallet address
     */
    fun isValidWalletAddress(address: String): Boolean {
        return walletService.isValidWalletAddress(address)
    }
}
