package com.example.kycapp.domain.models

/**
 * ComplianceBadge - Badge representing compliance status
 */
data class ComplianceBadge(
    val badgeId: String,
    val walletId: String,
    val badgeType: BadgeType,
    val issuedAt: Long,
    val expiresAt: Long,
    val issuer: String,
    val metadata: Map<String, String> = emptyMap(),
    val isRevoked: Boolean = false
) {
    fun isValid(): Boolean = !isRevoked && System.currentTimeMillis() < expiresAt
}

/**
 * Badge types available in the system
 */
enum class BadgeType(val displayName: String, val level: Int) {
    BASIC_KYC("Basic KYC", 1),
    ADVANCED_KYC("Advanced KYC", 2),
    GOVERNANCE_GRADE("Governance Grade", 3);
    
    companion object {
        fun fromString(value: String): BadgeType = when (value.lowercase()) {
            "basic_kyc", "basic" -> BASIC_KYC
            "advanced_kyc", "advanced" -> ADVANCED_KYC
            "governance_grade", "governance" -> GOVERNANCE_GRADE
            else -> BASIC_KYC
        }
    }
}

/**
 * Compliance status response from backend
 */
data class ComplianceStatusResponse(
    val walletId: String,
    val isCompliant: Boolean,
    val badge: ComplianceBadge?,
    val kycStatus: KycStatus,
    val lastVerified: Long,
    val riskScore: Int?,
    val restrictions: List<String> = emptyList()
)

/**
 * Badge validation request
 */
data class BadgeValidationRequest(
    val walletId: String,
    val badgeId: String?,
    val requiredBadgeType: BadgeType?,
    val checkExpiry: Boolean = true
)

/**
 * Badge validation result
 */
sealed class BadgeValidationResult {
    data class Valid(
        val badge: ComplianceBadge,
        val meetsRequirement: Boolean
    ) : BadgeValidationResult()
    
    data class Invalid(val reason: String) : BadgeValidationResult()
    object NotFound : BadgeValidationResult()
}
