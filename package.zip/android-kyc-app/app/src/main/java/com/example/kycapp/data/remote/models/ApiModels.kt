package com.example.kycapp.data.remote.models

import com.google.gson.annotations.SerializedName

/**
 * KYC Proof Request
 */
data class KycProofRequest(
    @SerializedName("wallet_id")
    val walletId: String,
    @SerializedName("personal_info")
    val personalInfo: PersonalInfoDto,
    @SerializedName("verification_data")
    val verificationData: Map<String, String>
)

/**
 * Personal Info DTO
 */
data class PersonalInfoDto(
    @SerializedName("full_name")
    val fullName: String,
    @SerializedName("date_of_birth")
    val dateOfBirth: String,
    @SerializedName("nationality")
    val nationality: String,
    @SerializedName("document_type")
    val documentType: String,
    @SerializedName("document_number")
    val documentNumber: String
)

/**
 * KYC Proof Response
 */
data class KycProofResponse(
    @SerializedName("proof_id")
    val proofId: String,
    @SerializedName("wallet_id")
    val walletId: String,
    @SerializedName("status")
    val status: String,
    @SerializedName("submitted_at")
    val submittedAt: Long
)

/**
 * Compliance Status Response DTO
 */
data class ComplianceStatusResponseDto(
    @SerializedName("wallet_id")
    val walletId: String,
    @SerializedName("is_compliant")
    val isCompliant: Boolean,
    @SerializedName("badge")
    val badge: BadgeResponse?,
    @SerializedName("kyc_status")
    val kycStatus: String,
    @SerializedName("last_verified")
    val lastVerified: Long,
    @SerializedName("risk_score")
    val riskScore: Int?,
    @SerializedName("restrictions")
    val restrictions: List<String>
)

/**
 * Badge Response
 */
data class BadgeResponse(
    @SerializedName("badge_id")
    val badgeId: String,
    @SerializedName("wallet_id")
    val walletId: String,
    @SerializedName("badge_type")
    val badgeType: String,
    @SerializedName("issued_at")
    val issuedAt: Long,
    @SerializedName("expires_at")
    val expiresAt: Long,
    @SerializedName("issuer")
    val issuer: String,
    @SerializedName("is_revoked")
    val isRevoked: Boolean
)

/**
 * Register Badge Request
 */
data class RegisterBadgeRequest(
    @SerializedName("wallet_id")
    val walletId: String,
    @SerializedName("badge_type")
    val badgeType: String,
    @SerializedName("metadata")
    val metadata: Map<String, String>
)

/**
 * Request Badge Request
 */
data class RequestBadgeRequest(
    @SerializedName("wallet_id")
    val walletId: String,
    @SerializedName("badge_type")
    val badgeType: String
)

/**
 * Revoke Badge Request
 */
data class RevokeBadgeRequest(
    @SerializedName("wallet_id")
    val walletId: String,
    @SerializedName("badge_id")
    val badgeId: String
)

/**
 * Revoke Badge Response
 */
data class RevokeBadgeResponse(
    @SerializedName("success")
    val success: Boolean,
    @SerializedName("message")
    val message: String
)

/**
 * Update Compliance Request
 */
data class UpdateComplianceRequest(
    @SerializedName("wallet_id")
    val walletId: String,
    @SerializedName("kyc_status")
    val kycStatus: String,
    @SerializedName("badge_id")
    val badgeId: String?
)

/**
 * Update Compliance Response
 */
data class UpdateComplianceResponse(
    @SerializedName("success")
    val success: Boolean,
    @SerializedName("wallet_id")
    val walletId: String,
    @SerializedName("updated_at")
    val updatedAt: Long
)

/**
 * Audit Log Request
 */
data class AuditLogRequest(
    @SerializedName("wallet_id")
    val walletId: String,
    @SerializedName("action")
    val action: String,
    @SerializedName("details")
    val details: Map<String, String>,
    @SerializedName("timestamp")
    val timestamp: Long
)

/**
 * Audit Log Response
 */
data class AuditLogResponse(
    @SerializedName("success")
    val success: Boolean,
    @SerializedName("log_id")
    val logId: String,
    @SerializedName("timestamp")
    val timestamp: Long
)
