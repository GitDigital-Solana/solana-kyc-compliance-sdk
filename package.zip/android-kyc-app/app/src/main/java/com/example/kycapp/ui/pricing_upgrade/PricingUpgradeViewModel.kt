package com.example.kycapp.ui.pricing_upgrade

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kycapp.application.KycApplication
import com.example.kycapp.service.BillingEngine
import kotlinx.coroutines.launch

/**
 * PricingUpgradeViewModel - Handles membership tier display and upgrades
 */
class PricingUpgradeViewModel : ViewModel() {
    
    private val billingEngine = KycApplication.instance.billingEngine
    
    private val _membershipTiers = MutableLiveData<List<BillingEngine.MembershipTier>>()
    val membershipTiers: LiveData<List<BillingEngine.MembershipTier>> = _membershipTiers
    
    private val _currentTier = MutableLiveData<String>()
    val currentTier: LiveData<String> = _currentTier
    
    private val _usageInfo = MutableLiveData<BillingEngine.UsageInfo?>()
    val usageInfo: LiveData<BillingEngine.UsageInfo?> = _usageInfo
    
    private val _upgradeResult = MutableLiveData<Boolean?>()
    val upgradeResult: LiveData<Boolean?> = _upgradeResult
    
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading
    
    init {
        loadData()
    }
    
    /**
     * Load membership data
     */
    fun loadData() {
        _membershipTiers.value = billingEngine.getMembershipTiers()
        
        viewModelScope.launch {
            _usageInfo.value = billingEngine.getCurrentUsage()
        }
    }
    
    /**
     * Upgrade to new tier
     */
    fun upgradeTier(tierId: String) {
        _isLoading.value = true
        
        viewModelScope.launch {
            val success = billingEngine.upgradeTier(tierId)
            _upgradeResult.value = success
            
            if (success) {
                _usageInfo.value = billingEngine.getCurrentUsage()
            }
            
            _isLoading.value = false
        }
    }
    
    /**
     * Clear upgrade result
     */
    fun clearUpgradeResult() {
        _upgradeResult.value = null
    }
}
