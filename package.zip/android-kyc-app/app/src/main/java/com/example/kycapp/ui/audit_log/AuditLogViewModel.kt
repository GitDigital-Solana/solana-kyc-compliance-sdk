package com.example.kycapp.ui.audit_log

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kycapp.application.KycApplication
import kotlinx.coroutines.launch

/**
 * AuditLogViewModel - Handles audit log display and export
 */
class AuditLogViewModel : ViewModel() {
    
    private val complianceRepository = KycApplication.instance.complianceRepository
    
    private val _auditLogs = MutableLiveData<List<AuditLogEntry>>()
    val auditLogs: LiveData<List<AuditLogEntry>> = _auditLogs
    
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading
    
    private val _exportResult = MutableLiveData<Boolean?>()
    val exportResult: LiveData<Boolean?> = _exportResult
    
    /**
     * Load audit logs
     */
    fun loadAuditLogs(walletId: String) {
        _isLoading.value = true
        
        viewModelScope.launch {
            try {
                // Submit sample audit log for demo
                complianceRepository.submitAuditLog(
                    walletId = walletId,
                    action = "AUDIT_LOG_VIEW",
                    details = mapOf("viewed" to "true")
                )
                
                // In production, fetch from backend
                _auditLogs.value = listOf(
                    AuditLogEntry(
                        id = "1",
                        timestamp = System.currentTimeMillis(),
                        action = "KYC_VERIFICATION",
                        details = "KYC proof submitted",
                        status = "SUCCESS"
                    )
                )
            } catch (e: Exception) {
                _auditLogs.value = emptyList()
            } finally {
                _isLoading.value = false
            }
        }
    }
    
    /**
     * Export audit logs
     */
    fun exportAuditLogs(walletId: String) {
        _isLoading.value = true
        
        viewModelScope.launch {
            val success = complianceRepository.submitAuditLog(
                walletId = walletId,
                action = "AUDIT_LOG_EXPORT",
                details = mapOf("exported" to "true")
            )
            _exportResult.value = success
            _isLoading.value = false
        }
    }
    
    /**
     * Clear export result
     */
    fun clearExportResult() {
        _exportResult.value = null
    }
}

/**
 * Audit Log Entry
 */
data class AuditLogEntry(
    val id: String,
    val timestamp: Long,
    val action: String,
    val details: String,
    val status: String
)
