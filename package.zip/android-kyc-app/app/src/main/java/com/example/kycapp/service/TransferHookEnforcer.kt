package com.example.kycapp.service

import android.content.Context
import com.example.kycapp.data.local.SecureKeyStore
import com.example.kycapp.domain.models.BadgeType
import com.example.kycapp.util.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * TransferHookEnforcer - Enforces transfer restrictions by compliance status
 * 
 * This service implements the transfer-hook mechanism that blocks
 * non-KYC compliant wallets from executing transfers.
 */
class TransferHookEnforcer(context: Context) {
    
    private val secureKeyStore = SecureKeyStore(context)
    private val complianceRegistryClient = ComplianceRegistryClient(context)
    
    /**
     * Result of transfer hook validation
     */
    sealed class TransferHookResult {
        object Approved : TransferHookResult()
        data class Blocked(val reason: String, val code: String) : TransferHookResult()
        data class RequiresUpgrade(val currentTier: String, val requiredTier: String) : TransferHookResult()
    }
    
    /**
     * Validate transfer for source wallet
     */
    suspend fun validateSourceWallet(sourceWalletId: String): TransferHookResult = withContext(Dispatchers.IO) {
        try {
            // Check API usage limits
            val usageCount = secureKeyStore.incrementApiUsageCount("transfer_hook")
            val tier = secureKeyStore.getMembershipTier()
            val limit = getTransferHookLimit(tier)
            
            if (limit != -1 && usageCount > limit) {
                return@withContext TransferHookResult.RequiresUpgrade(tier, getNextTier(tier))
            }
            
            // Check compliance status
            val isCompliant = complianceRegistryClient.isCompliantForTransfer(sourceWalletId)
            if (!isCompliant) {
                return@withContext TransferHookResult.Blocked(
                    "Source wallet is not KYC compliant",
                    Constants.ERROR_COMPLIANCE_FAILED
                )
            }
            
            TransferHookResult.Approved
        } catch (e: Exception) {
            TransferHookResult.Blocked(
                "Transfer validation failed: ${e.message}",
                Constants.ERROR_NETWORK
            )
        }
    }
    
    /**
     * Validate transfer for destination wallet
     */
    suspend fun validateDestinationWallet(destWalletId: String): TransferHookResult = withContext(Dispatchers.IO) {
        try {
            // Check if destination is KYC compliant
            val isCompliant = complianceRegistryClient.isCompliantForTransfer(destWalletId)
            if (!isCompliant) {
                return@withContext TransferHookResult.Blocked(
                    "Destination wallet is not KYC compliant",
                    Constants.ERROR_COMPLIANCE_FAILED
                )
            }
            
            TransferHookResult.Approved
        } catch (e: Exception) {
            TransferHookResult.Blocked(
                "Destination validation failed: ${e.message}",
                Constants.ERROR_NETWORK
            )
        }
    }
    
    /**
     * Validate complete transfer (both source and destination)
     */
    suspend fun validateTransfer(
        sourceWalletId: String,
        destWalletId: String,
        amount: Double
    ): TransferHookResult = withContext(Dispatchers.IO) {
        // Check minimum amount
        if (amount < Constants.MIN_TRANSFER_AMOUNT) {
            return@withContext TransferHookResult.Blocked(
                "Transfer amount below minimum: ${Constants.MIN_TRANSFER_AMOUNT}",
                Constants.ERROR_COMPLIANCE_FAILED
            )
        }
        
        // Validate source
        val sourceResult = validateSourceWallet(sourceWalletId)
        if (sourceResult !is TransferHookResult.Approved) {
            return@withContext sourceResult
        }
        
        // Validate destination
        val destResult = validateDestinationWallet(destWalletId)
        if (destResult !is TransferHookResult.Approved) {
            return@withContext destResult
        }
        
        // Log transfer hook invocation
        complianceRegistryClient.submitAuditLog(
            walletId = sourceWalletId,
            action = "TRANSFER_HOOK_INVOCATION",
            details = mapOf(
                "destination" to destWalletId,
                "amount" to amount.toString(),
                "result" to "APPROVED"
            )
        )
        
        TransferHookResult.Approved
    }
    
    /**
     * Check if wallet requires specific badge level for transfer
     */
    suspend fun requiresBadgeLevel(walletId: String, requiredLevel: BadgeType): Boolean = withContext(Dispatchers.IO) {
        val validationResult = complianceRegistryClient.verifyBadgeOnChain(walletId)
        
        when (validationResult) {
            is com.example.kycapp.domain.models.BadgeValidationResult.Valid -> {
                validationResult.badge.badgeType.level >= requiredLevel.level
            }
            else -> false
        }
    }
    
    /**
     * Get transfer hook limit for membership tier
     */
    private fun getTransferHookLimit(tier: String): Int = when (tier) {
        Constants.TIER_FREE -> Constants.RateLimits.FREE_TRANSFER_HOOKS
        Constants.TIER_BASIC -> Constants.RateLimits.BASIC_TRANSFER_HOOKS
        Constants.TIER_PRO -> Constants.RateLimits.PRO_TRANSFER_HOOKS
        Constants.TIER_ENTERPRISE -> Constants.RateLimits.ENTERPRISE_TRANSFER_HOOKS
        else -> Constants.RateLimits.FREE_TRANSFER_HOOKS
    }
    
    /**
     * Get next tier for upgrade
     */
    private fun getNextTier(currentTier: String): String = when (currentTier) {
        Constants.TIER_FREE -> Constants.TIER_BASIC
        Constants.TIER_BASIC -> Constants.TIER_PRO
        Constants.TIER_PRO -> Constants.TIER_ENTERPRISE
        else -> Constants.TIER_ENTERPRISE
    }
    
    /**
     * Get transfer restrictions for wallet
     */
    suspend fun getTransferRestrictions(walletId: String): List<String> = withContext(Dispatchers.IO) {
        complianceRegistryClient.getComplianceRestrictions(walletId)
    }
}
