package com.example.kycapp.domain.models

/**
 * KycProof - Zero-knowledge proof for KYC verification
 */
data class KycProof(
    val proofId: String,
    val walletId: String,
    val proofData: String,
    val publicSignals: List<String>,
    val circuitId: String,
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long,
    val isValid: Boolean = true
) {
    fun isExpired(): Boolean = System.currentTimeMillis() > expiresAt
}

/**
 * KYC proof generation request
 */
data class KycProofRequest(
    val walletId: String,
    val personalInfo: PersonalInfo,
    val verificationData: Map<String, String>
)

/**
 * Personal information for KYC
 */
data class PersonalInfo(
    val fullName: String,
    val dateOfBirth: String,
    val nationality: String,
    val documentType: String,
    val documentNumber: String
)

/**
 * KYC proof generation result
 */
sealed class KycProofResult {
    data class Success(val proof: KycProof) : KycProofResult()
    data class Error(val message: String, val code: String) : KycProofResult()
    object InProgress : KycProofResult()
}

/**
 * KYC submission status
 */
enum class KycStatus {
    NOT_STARTED,
    IN_PROGRESS,
    PENDING_VERIFICATION,
    VERIFIED,
    REJECTED,
    EXPIRED
}
