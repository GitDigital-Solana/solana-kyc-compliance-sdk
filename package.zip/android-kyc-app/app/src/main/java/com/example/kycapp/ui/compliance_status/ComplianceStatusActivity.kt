package com.example.kycapp.ui.compliance_status

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.kycapp.R
import com.example.kycapp.application.KycApplication
import com.example.kycapp.databinding.ActivityComplianceStatusBinding
import com.example.kycapp.ui.audit_log.AuditLogActivity
import com.example.kycapp.ui.kyc.KycActivity
import com.example.kycapp.ui.pricing_upgrade.PricingUpgradeActivity

/**
 * ComplianceStatusActivity - Displays current KYC status and badges
 */
class ComplianceStatusActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityComplianceStatusBinding
    private val viewModel: ComplianceStatusViewModel by viewModels()
    private val app by lazy { KycApplication.instance }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityComplianceStatusBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupUI()
        observeViewModel()
        loadData()
    }
    
    private fun setupUI() {
        binding.btnStartKyc.setOnClickListener {
            navigateToKyc()
        }
        
        binding.btnUpgrade.setOnClickListener {
            navigateToPricing()
        }
        
        binding.btnAuditLog.setOnClickListener {
            navigateToAuditLog()
        }
        
        binding.btnRefresh.setOnClickListener {
            loadData()
        }
    }
    
    private fun loadData() {
        // Get first wallet ID (in production, manage multiple wallets)
        viewModel.loadComplianceStatus("default_wallet")
    }
    
    private fun observeViewModel() {
        viewModel.complianceStatus.observe(this) { status ->
            if (status != null) {
                updateUI(status.isCompliant, status.kycStatus.name)
            }
        }
        
        viewModel.badge.observe(this) { badge ->
            if (badge != null) {
                binding.tvBadgeType.text = badge.badgeType.displayName
                binding.tvBadgeType.visibility = View.VISIBLE
            } else {
                binding.tvBadgeType.visibility = View.GONE
            }
        }
        
        viewModel.isLoading.observe(this) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }
        
        viewModel.errorMessage.observe(this) { error ->
            error?.let {
                Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
                viewModel.clearError()
            }
        }
    }
    
    private fun updateUI(isCompliant: Boolean, kycStatus: String) {
        if (isCompliant) {
            binding.tvComplianceStatus.text = getString(R.string.compliance_compliant)
            binding.tvComplianceStatus.setTextColor(getColor(R.color.success))
            binding.btnStartKyc.visibility = View.GONE
        } else {
            binding.tvComplianceStatus.text = getString(R.string.compliance_non_compliant)
            binding.tvComplianceStatus.setTextColor(getColor(R.color.error))
            binding.btnStartKyc.visibility = View.VISIBLE
        }
        
        binding.tvKycStatus.text = "KYC Status: $kycStatus"
    }
    
    private fun navigateToKyc() {
        startActivity(Intent(this, KycActivity::class.java))
    }
    
    private fun navigateToPricing() {
        startActivity(Intent(this, PricingUpgradeActivity::class.java))
    }
    
    private fun navigateToAuditLog() {
        startActivity(Intent(this, AuditLogActivity::class.java))
    }
}
