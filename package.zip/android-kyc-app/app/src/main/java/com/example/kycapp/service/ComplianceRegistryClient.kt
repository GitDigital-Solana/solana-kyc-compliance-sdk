package com.example.kycapp.service

import android.content.Context
import com.example.kycapp.data.local.SecureKeyStore
import com.example.kycapp.data.remote.ComplianceBackendApi
import com.example.kycapp.domain.models.*
import com.example.kycapp.util.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * ComplianceRegistryClient - Backend communication for compliance status and badges
 */
class ComplianceRegistryClient(context: Context) {
    
    private val secureKeyStore = SecureKeyStore(context)
    private val complianceBackendApi = ComplianceBackendApi()
    
    /**
     * Get compliance status for a wallet
     */
    suspend fun getComplianceStatus(walletId: String): ComplianceStatusResponse = withContext(Dispatchers.IO) {
        try {
            val response = complianceBackendApi.getComplianceStatus(walletId)
            if (response.isSuccessful && response.body() != null) {
                response.body()!!
            } else {
                // Return default non-compliant status
                ComplianceStatusResponse(
                    walletId = walletId,
                    isCompliant = false,
                    badge = null,
                    kycStatus = KycStatus.NOT_STARTED,
                    lastVerified = 0
                )
            }
        } catch (e: Exception) {
            // Try to get local badge if network fails
            val localBadge = secureKeyStore.getComplianceBadge(walletId)
            ComplianceStatusResponse(
                walletId = walletId,
                isCompliant = localBadge != null,
                badge = null,
                kycStatus = if (localBadge != null) KycStatus.VERIFIED else KycStatus.NOT_STARTED,
                lastVerified = 0
            )
        }
    }
    
    /**
     * Register compliance badge for wallet
     */
    suspend fun registerComplianceBadge(badge: ComplianceBadge): Boolean = withContext(Dispatchers.IO) {
        try {
            // Store locally first
            secureKeyStore.storeComplianceBadge(badge.walletId, badge.badgeId)
            
            // Submit to backend
            val response = complianceBackendApi.registerBadge(badge)
            response.isSuccessful
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * Verify compliance badge on-chain
     */
    suspend fun verifyBadgeOnChain(walletId: String): BadgeValidationResult = withContext(Dispatchers.IO) {
        try {
            val response = complianceBackendApi.verifyBadge(walletId)
            if (response.isSuccessful && response.body() != null) {
                val badgeResponse = response.body()!!
                val badge = ComplianceBadge(
                    badgeId = badgeResponse.badgeId,
                    walletId = walletId,
                    badgeType = BadgeType.fromString(badgeResponse.badgeType),
                    issuedAt = badgeResponse.issuedAt,
                    expiresAt = badgeResponse.expiresAt,
                    issuer = badgeResponse.issuer
                )
                
                if (badge.isValid()) {
                    BadgeValidationResult.Valid(badge, true)
                } else {
                    BadgeValidationResult.Invalid("Badge is expired or revoked")
                }
            } else {
                BadgeValidationResult.NotFound
            }
        } catch (e: Exception) {
            BadgeValidationResult.Invalid("Verification failed: ${e.message}")
        }
    }
    
    /**
     * Check if wallet is KYC compliant for transfers
     */
    suspend fun isCompliantForTransfer(walletId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val status = getComplianceStatus(walletId)
            status.isCompliant && status.kycStatus == KycStatus.VERIFIED
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * Get compliance restrictions for wallet
     */
    suspend fun getComplianceRestrictions(walletId: String): List<String> = withContext(Dispatchers.IO) {
        try {
            val status = getComplianceStatus(walletId)
            status.restrictions
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    /**
     * Submit compliance audit log
     */
    suspend fun submitAuditLog(
        walletId: String,
        action: String,
        details: Map<String, String>
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val response = complianceBackendApi.submitAuditLog(
                walletId = walletId,
                action = action,
                details = details,
                timestamp = System.currentTimeMillis()
            )
            response.isSuccessful
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * Revoke compliance badge
     */
    suspend fun revokeBadge(walletId: String, badgeId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val response = complianceBackendApi.revokeBadge(walletId, badgeId)
            if (response.isSuccessful) {
                // Clear local storage
                secureKeyStore.storeComplianceBadge(walletId, "")
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * Update compliance status after KYC verification
     */
    suspend fun updateComplianceStatus(
        walletId: String,
        kycStatus: KycStatus,
        badge: ComplianceBadge?
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val response = complianceBackendApi.updateComplianceStatus(
                walletId = walletId,
                kycStatus = kycStatus.name,
                badgeId = badge?.badgeId
            )
            
            if (response.isSuccessful && badge != null) {
                registerComplianceBadge(badge)
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }
}
