package com.example.kycapp.ui.kyc

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.kycapp.R
import com.example.kycapp.databinding.ActivityKycBinding
import com.example.kycapp.domain.models.PersonalInfo
import com.example.kycapp.ui.compliance_status.ComplianceStatusActivity

/**
 * KycActivity - Handles KYC enrollment process
 */
class KycActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityKycBinding
    private val viewModel: KycViewModel by viewModels()
    
    companion object {
        const val EXTRA_WALLET_ID = "wallet_id"
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityKycBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        val walletId = intent.getStringExtra(EXTRA_WALLET_ID)
        if (walletId == null) {
            finish()
            return
        }
        
        viewModel.setWalletId(walletId)
        
        setupUI()
        observeViewModel()
    }
    
    /**
     * Setup UI components
     */
    private fun setupUI() {
        binding.btnStartKyc.setOnClickListener {
            val personalInfo = collectPersonalInfo()
            viewModel.startKycVerification(personalInfo)
        }
        
        binding.btnContinue.setOnClickListener {
            navigateToComplianceStatus()
        }
    }
    
    /**
     * Collect personal information from form
     */
    private fun collectPersonalInfo(): PersonalInfo {
        return PersonalInfo(
            fullName = binding.etFullName.text.toString(),
            dateOfBirth = binding.etDateOfBirth.text.toString(),
            nationality = binding.etNationality.text.toString(),
            documentType = binding.etDocumentType.text.toString(),
            documentNumber = binding.etDocumentNumber.text.toString()
        )
    }
    
    /**
     * Observe ViewModel state
     */
    private fun observeViewModel() {
        viewModel.kycState.observe(this) { state ->
            when (state) {
                is KycUiState.NotStarted -> showForm()
                is KycUiState.InProgress -> showLoading("KYC in progress...")
                is KycUiState.Pending -> showPending()
                is KycUiState.Verified -> showVerified()
                is KycUiState.Rejected -> showRejected()
                is KycUiState.Expired -> showExpired()
                is KycUiState.Error -> {
                    Toast.makeText(this, state.message, Toast.LENGTH_LONG).show()
                    showForm()
                }
            }
        }
        
        viewModel.isLoading.observe(this) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
            binding.btnStartKyc.isEnabled = !isLoading
        }
        
        viewModel.errorMessage.observe(this) { error ->
            error?.let {
                Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
                viewModel.clearError()
            }
        }
    }
    
    private fun showForm() {
        binding.formLayout.visibility = View.VISIBLE
        binding.statusLayout.visibility = View.GONE
    }
    
    private fun showLoading(message: String) {
        binding.formLayout.visibility = View.GONE
        binding.statusLayout.visibility = View.VISIBLE
        binding.tvStatus.text = message
        binding.progressBar.visibility = View.VISIBLE
    }
    
    private fun showPending() {
        binding.formLayout.visibility = View.GONE
        binding.statusLayout.visibility = View.VISIBLE
        binding.tvStatus.text = getString(R.string.kyc_pending)
        binding.progressBar.visibility = View.GONE
        binding.btnContinue.visibility = View.VISIBLE
    }
    
    private fun showVerified() {
        binding.formLayout.visibility = View.GONE
        binding.statusLayout.visibility = View.VISIBLE
        binding.tvStatus.text = getString(R.string.kyc_verified)
        binding.progressBar.visibility = View.GONE
        binding.btnContinue.visibility = View.VISIBLE
    }
    
    private fun showRejected() {
        binding.formLayout.visibility = View.GONE
        binding.statusLayout.visibility = View.VISIBLE
        binding.tvStatus.text = getString(R.string.kyc_rejected)
        binding.progressBar.visibility = View.GONE
        binding.btnStartKyc.visibility = View.VISIBLE
    }
    
    private fun showExpired() {
        binding.formLayout.visibility = View.VISIBLE
        binding.statusLayout.visibility = View.GONE
        Toast.makeText(this, "KYC expired. Please re-verify.", Toast.LENGTH_LONG).show()
    }
    
    private fun navigateToComplianceStatus() {
        val intent = Intent(this, ComplianceStatusActivity::class.java)
        startActivity(intent)
        finish()
    }
}
