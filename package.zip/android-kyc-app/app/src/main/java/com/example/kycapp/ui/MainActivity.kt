package com.example.kycapp.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.kycapp.application.KycApplication
import com.example.kycapp.databinding.ActivityMainBinding
import com.example.kycapp.ui.onboarding.OnboardingActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * MainActivity - Entry point for the application
 */
class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private val app by lazy { KycApplication.instance }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        checkUserSetup()
    }
    
    /**
     * Check if user has completed onboarding and wallet setup
     */
    private fun checkUserSetup() {
        CoroutineScope(Dispatchers.Main).launch {
            val hasWallet = app.walletRepository.getAllWallets().isNotEmpty()
            
            if (hasWallet) {
                // User has wallet, show main dashboard
                showMainDashboard()
            } else {
                // User needs to complete onboarding
                navigateToOnboarding()
            }
        }
    }
    
    /**
     * Show main dashboard
     */
    private fun showMainDashboard() {
        // For now, navigate to compliance status
        navigateToComplianceStatus()
    }
    
    /**
     * Navigate to onboarding
     */
    private fun navigateToOnboarding() {
        val intent = Intent(this, OnboardingActivity::class.java)
        startActivity(intent)
        finish()
    }
    
    /**
     * Navigate to compliance status
     */
    private fun navigateToComplianceStatus() {
        val intent = Intent(this, com.example.kycapp.ui.compliance_status.ComplianceStatusActivity::class.java)
        startActivity(intent)
        finish()
    }
}
