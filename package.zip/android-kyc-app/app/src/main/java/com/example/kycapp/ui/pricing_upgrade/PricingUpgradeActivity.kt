package com.example.kycapp.ui.pricing_upgrade

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.kycapp.databinding.ActivityPricingUpgradeBinding
import com.example.kycapp.service.BillingEngine

/**
 * PricingUpgradeActivity - Displays membership tiers and handles upgrades
 */
class PricingUpgradeActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityPricingUpgradeBinding
    private val viewModel: PricingUpgradeViewModel by viewModels()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPricingUpgradeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupUI()
        observeViewModel()
    }
    
    private fun setupUI() {
        binding.toolbar.setNavigationOnClickListener {
            finish()
        }
    }
    
    private fun observeViewModel() {
        viewModel.membershipTiers.observe(this) { tiers ->
            displayTiers(tiers)
        }
        
        viewModel.usageInfo.observe(this) { usage ->
            usage?.let {
                binding.tvCurrentTier.text = "Current: ${it.tier.uppercase()}"
                updateUsageDisplay(it)
            }
        }
        
        viewModel.upgradeResult.observe(this) { result ->
            result?.let {
                if (it) {
                    Toast.makeText(this, "Upgrade successful!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Upgrade failed", Toast.LENGTH_SHORT).show()
                }
                viewModel.clearUpgradeResult()
            }
        }
    }
    
    private fun displayTiers(tiers: List<BillingEngine.MembershipTier>) {
        // Display tier cards - simplified for demo
        val tierText = StringBuilder()
        tiers.forEach { tier ->
            tierText.append("${tier.displayName}: $${tier.price}/${tier.billingPeriod}\n")
            tierText.append("- ${tier.features.joinToString("\n  ")}\n\n")
        }
        binding.tvTiersInfo.text = tierText.toString()
    }
    
    private fun updateUsageDisplay(usage: BillingEngine.UsageInfo) {
        val usageText = """
            KYC Verifications: ${usage.kycVerificationsUsed}/${usage.kycVerificationsLimit}
            Transfer Hooks: ${usage.transferHooksUsed}/${usage.transferHooksLimit}
            Badge Validations: ${usage.badgeValidationsUsed}/${usage.badgeValidationsLimit}
            Audit Logs: ${usage.auditLogsUsed}/${usage.auditLogsLimit}
        """.trimIndent()
        binding.tvUsageInfo.text = usageText
    }
}
