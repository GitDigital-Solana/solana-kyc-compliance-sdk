package com.example.kycapp.domain.models

/**
 * Wallet - Represents user's blockchain wallet
 */
data class Wallet(
    val id: String,
    val publicKey: String,
    val privateKey: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val balance: Double = 0.0,
    val isKycCompliant: Boolean = false,
    val complianceBadge: ComplianceBadge? = null
)

/**
 * Wallet creation result
 */
sealed class WalletResult {
    data class Success(val wallet: Wallet) : WalletResult()
    data class Error(val message: String, val code: String) : WalletResult()
}

/**
 * Wallet balance information
 */
data class WalletBalance(
    val walletId: String,
    val solBalance: Double,
    val tokenBalances: Map<String, Double> = emptyMap(),
    val lastUpdated: Long = System.currentTimeMillis()
)
