package com.example.kycapp.application

import android.app.Application
import com.example.kycapp.data.local.SecureKeyStore
import com.example.kycapp.data.repositories.ComplianceRepository
import com.example.kycapp.data.repositories.KycRepository
import com.example.kycapp.data.repositories.WalletRepository
import com.example.kycapp.service.*

/**
 * KycApplication - Application class for zk-Solana KYC Compliance App
 */
class KycApplication : Application() {
    
    // Services
    lateinit var walletService: WalletService
        private set
    lateinit var kycService: KycService
        private set
    lateinit var zkProofService: ZkProofService
        private set
    lateinit var complianceRegistryClient: ComplianceRegistryClient
        private set
    lateinit var transferHookEnforcer: TransferHookEnforcer
        private set
    lateinit var badgeValidationClient: BadgeValidationClient
        private set
    lateinit var billingEngine: BillingEngine
        private set
    
    // Repositories
    lateinit var walletRepository: WalletRepository
        private set
    lateinit var kycRepository: KycRepository
        private set
    lateinit var complianceRepository: ComplianceRepository
        private set
    
    // Secure Storage
    lateinit var secureKeyStore: SecureKeyStore
        private set
    
    override fun onCreate() {
        super.onCreate()
        instance = this
        initializeServices()
        initializeRepositories()
    }
    
    /**
     * Initialize all services
     */
    private fun initializeServices() {
        secureKeyStore = SecureKeyStore(this)
        
        walletService = WalletService(this)
        kycService = KycService(this)
        zkProofService = ZkProofService(this)
        complianceRegistryClient = ComplianceRegistryClient(this)
        transferHookEnforcer = TransferHookEnforcer(this)
        badgeValidationClient = BadgeValidationClient(this)
        billingEngine = BillingEngine(this)
    }
    
    /**
     * Initialize all repositories
     */
    private fun initializeRepositories() {
        walletRepository = WalletRepository(this)
        kycRepository = KycRepository(this)
        complianceRepository = ComplianceRepository(this)
    }
    
    companion object {
        lateinit var instance: KycApplication
            private set
    }
}
