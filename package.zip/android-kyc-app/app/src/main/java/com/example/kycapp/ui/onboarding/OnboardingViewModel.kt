package com.example.kycapp.ui.onboarding

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kycapp.application.KycApplication
import com.example.kycapp.domain.models.Wallet
import com.example.kycapp.domain.models.WalletResult
import kotlinx.coroutines.launch

/**
 * OnboardingViewModel - Handles onboarding flow logic
 */
class OnboardingViewModel : ViewModel() {
    
    private val walletRepository = KycApplication.instance.walletRepository
    
    // UI State
    private val _walletState = MutableLiveData<WalletUiState>()
    val walletState: LiveData<WalletUiState> = _walletState
    
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading
    
    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> = _errorMessage
    
    /**
     * Create new wallet
     */
    fun createWallet() {
        _isLoading.value = true
        _errorMessage.value = null
        
        viewModelScope.launch {
            val result = walletRepository.createWallet()
            
            _isLoading.value = false
            
            when (result) {
                is WalletResult.Success -> {
                    _walletState.value = WalletUiState.Success(result.wallet)
                }
                is WalletResult.Error -> {
                    _walletState.value = WalletUiState.Error(result.message)
                    _errorMessage.value = result.message
                }
            }
        }
    }
    
    /**
     * Clear error message
     */
    fun clearError() {
        _errorMessage.value = null
    }
    
    /**
     * Reset wallet state
     */
    fun resetState() {
        _walletState.value = WalletUiState.Idle
    }
}

/**
 * Wallet UI State
 */
sealed class WalletUiState {
    object Idle : WalletUiState()
    object Loading : WalletUiState()
    data class Success(val wallet: Wallet) : WalletUiState()
    data class Error(val message: String) : WalletUiState()
}
