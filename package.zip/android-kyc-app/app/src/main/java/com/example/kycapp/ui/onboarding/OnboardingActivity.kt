package com.example.kycapp.ui.onboarding

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.kycapp.databinding.ActivityOnboardingBinding
import com.example.kycapp.ui.kyc.KycActivity

/**
 * OnboardingActivity - Guides user through wallet creation and initial setup
 */
class OnboardingActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityOnboardingBinding
    private val viewModel: OnboardingViewModel by viewModels()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOnboardingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupUI()
        observeViewModel()
    }
    
    /**
     * Setup UI components
     */
    private fun setupUI() {
        binding.btnCreateWallet.setOnClickListener {
            viewModel.createWallet()
        }
    }
    
    /**
     * Observe ViewModel state
     */
    private fun observeViewModel() {
        viewModel.isLoading.observe(this) { isLoading ->
            binding.btnCreateWallet.isEnabled = !isLoading
            binding.progressBar.visibility = if (isLoading) android.view.View.VISIBLE else android.view.View.GONE
        }
        
        viewModel.walletState.observe(this) { state ->
            when (state) {
                is WalletUiState.Success -> {
                    Toast.makeText(this, "Wallet created: ${state.wallet.id}", Toast.LENGTH_LONG).show()
                    navigateToKyc(state.wallet.id)
                }
                is WalletUiState.Error -> {
                    Toast.makeText(this, "Error: ${state.message}", Toast.LENGTH_LONG).show()
                }
                else -> {}
            }
        }
        
        viewModel.errorMessage.observe(this) { error ->
            error?.let {
                Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
                viewModel.clearError()
            }
        }
    }
    
    /**
     * Navigate to KYC screen
     */
    private fun navigateToKyc(walletId: String) {
        val intent = Intent(this, KycActivity::class.java).apply {
            putExtra(KycActivity.EXTRA_WALLET_ID, walletId)
        }
        startActivity(intent)
        finish()
    }
}
