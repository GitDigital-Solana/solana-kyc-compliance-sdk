package com.example.kycapp.service

import android.content.Context
import com.example.kycapp.data.local.SecureKeyStore
import com.example.kycapp.util.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * BillingEngine - Manages API usage metering, thresholds, and pricing upgrades
 */
class BillingEngine(context: Context) {
    
    private val secureKeyStore = SecureKeyStore(context)
    
    /**
     * Membership tier information
     */
    data class MembershipTier(
        val tierId: String,
        val displayName: String,
        val price: Double,
        val billingPeriod: String,
        val features: List<String>,
        val limits: TierLimits
    )
    
    /**
     * API rate limits for a tier
     */
    data class TierLimits(
        val kycVerifications: Int,
        val transferHooks: Int,
        val badgeValidations: Int,
        val auditLogs: Int
    )
    
    /**
     * Current usage information
     */
    data class UsageInfo(
        val tier: String,
        val kycVerificationsUsed: Int,
        val kycVerificationsLimit: Int,
        val transferHooksUsed: Int,
        val transferHooksLimit: Int,
        val badgeValidationsUsed: Int,
        val badgeValidationsLimit: Int,
        val auditLogsUsed: Int,
        val auditLogsLimit: Int,
        val resetDate: Long
    )
    
    /**
     * Get all available membership tiers
     */
    fun getMembershipTiers(): List<MembershipTier> = listOf(
        MembershipTier(
            tierId = Constants.TIER_FREE,
            displayName = "Free",
            price = 0.0,
            billingPeriod = "Forever",
            features = listOf(
                "Basic wallet creation",
                "10 KYC verifications/month",
                "50 transfer-hook invocations/month",
                "100 badge validations/month",
                "5 audit log exports/month"
            ),
            limits = TierLimits(
                kycVerifications = Constants.RateLimits.FREE_KYC_VERIFICATIONS,
                transferHooks = Constants.RateLimits.FREE_TRANSFER_HOOKS,
                badgeValidations = Constants.RateLimits.FREE_BADGE_VALIDATIONS,
                auditLogs = Constants.RateLimits.FREE_AUDIT_LOGS
            )
        ),
        MembershipTier(
            tierId = Constants.TIER_BASIC,
            displayName = "Basic",
            price = 9.99,
            billingPeriod = "month",
            features = listOf(
                "Everything in Free",
                "50 KYC verifications/month",
                "250 transfer-hook invocations/month",
                "500 badge validations/month",
                "50 audit log exports/month",
                "Priority support"
            ),
            limits = TierLimits(
                kycVerifications = Constants.RateLimits.BASIC_KYC_VERIFICATIONS,
                transferHooks = Constants.RateLimits.BASIC_TRANSFER_HOOKS,
                badgeValidations = Constants.RateLimits.BASIC_BADGE_VALIDATIONS,
                auditLogs = Constants.RateLimits.BASIC_AUDIT_LOGS
            )
        ),
        MembershipTier(
            tierId = Constants.TIER_PRO,
            displayName = "Pro",
            price = 29.99,
            billingPeriod = "month",
            features = listOf(
                "Everything in Basic",
                "200 KYC verifications/month",
                "1000 transfer-hook invocations/month",
                "2000 badge validations/month",
                "200 audit log exports/month",
                "Advanced badge schemas",
                "Priority email support"
            ),
            limits = TierLimits(
                kycVerifications = Constants.RateLimits.PRO_KYC_VERIFICATIONS,
                transferHooks = Constants.RateLimits.PRO_TRANSFER_HOOKS,
                badgeValidations = Constants.RateLimits.PRO_BADGE_VALIDATIONS,
                auditLogs = Constants.RateLimits.PRO_AUDIT_LOGS
            )
        ),
        MembershipTier(
            tierId = Constants.TIER_ENTERPRISE,
            displayName = "Enterprise",
            price = 99.99,
            billingPeriod = "month",
            features = listOf(
                "Everything in Pro",
                "Unlimited KYC verifications",
                "Unlimited transfer-hook invocations",
                "Unlimited badge validations",
                "Unlimited audit log exports",
                "Governance-grade thresholds",
                "Dedicated support",
                "Custom integrations"
            ),
            limits = TierLimits(
                kycVerifications = Constants.RateLimits.ENTERPRISE_KYC_VERIFICATIONS,
                transferHooks = Constants.RateLimits.ENTERPRISE_TRANSFER_HOOKS,
                badgeValidations = Constants.RateLimits.ENTERPRISE_BADGE_VALIDATIONS,
                auditLogs = Constants.RateLimits.ENTERPRISE_AUDIT_LOGS
            )
        )
    )
    
    /**
     * Get current usage information
     */
    suspend fun getCurrentUsage(): UsageInfo = withContext(Dispatchers.IO) {
        val tier = secureKeyStore.getMembershipTier()
        val limits = getTierLimits(tier)
        
        UsageInfo(
            tier = tier,
            kycVerificationsUsed = secureKeyStore.getApiUsageCount("kyc_verification"),
            kycVerificationsLimit = limits.kycVerifications,
            transferHooksUsed = secureKeyStore.getApiUsageCount("transfer_hook"),
            transferHooksLimit = limits.transferHooks,
            badgeValidationsUsed = secureKeyStore.getApiUsageCount("badge_validation"),
            badgeValidationsLimit = limits.badgeValidations,
            auditLogsUsed = secureKeyStore.getApiUsageCount("audit_log"),
            auditLogsLimit = limits.auditLogs,
            resetDate = getNextResetDate()
        )
    }
    
    /**
     * Check if user can make API call
     */
    suspend fun canMakeApiCall(type: String): Boolean = withContext(Dispatchers.IO) {
        val usage = getCurrentUsage()
        val currentCount = secureKeyStore.getApiUsageCount(type)
        
        when (type) {
            "kyc_verification" -> usage.kycVerificationsLimit == -1 || currentCount < usage.kycVerificationsLimit
            "transfer_hook" -> usage.transferHooksLimit == -1 || currentCount < usage.transferHooksLimit
            "badge_validation" -> usage.badgeValidationsLimit == -1 || currentCount < usage.badgeValidationsLimit
            "audit_log" -> usage.auditLogsLimit == -1 || currentCount < usage.auditLogsLimit
            else -> true
        }
    }
    
    /**
     * Record API call
     */
    suspend fun recordApiCall(type: String): Int = withContext(Dispatchers.IO) {
        secureKeyStore.incrementApiUsageCount(type)
    }
    
    /**
     * Upgrade membership tier
     */
    suspend fun upgradeTier(newTier: String): Boolean = withContext(Dispatchers.IO) {
        try {
            // In production, this would initiate payment flow
            secureKeyStore.storeMembershipTier(newTier)
            true
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * Get tier limits
     */
    private fun getTierLimits(tier: String): TierLimits {
        return when (tier) {
            Constants.TIER_FREE -> TierLimits(
                Constants.RateLimits.FREE_KYC_VERIFICATIONS,
                Constants.RateLimits.FREE_TRANSFER_HOOKS,
                Constants.RateLimits.FREE_BADGE_VALIDATIONS,
                Constants.RateLimits.FREE_AUDIT_LOGS
            )
            Constants.TIER_BASIC -> TierLimits(
                Constants.RateLimits.BASIC_KYC_VERIFICATIONS,
                Constants.RateLimits.BASIC_TRANSFER_HOOKS,
                Constants.RateLimits.BASIC_BADGE_VALIDATIONS,
                Constants.RateLimits.BASIC_AUDIT_LOGS
            )
            Constants.TIER_PRO -> TierLimits(
                Constants.RateLimits.PRO_KYC_VERIFICATIONS,
                Constants.RateLimits.PRO_TRANSFER_HOOKS,
                Constants.RateLimits.PRO_BADGE_VALIDATIONS,
                Constants.RateLimits.PRO_AUDIT_LOGS
            )
            Constants.TIER_ENTERPRISE -> TierLimits(
                Constants.RateLimits.ENTERPRISE_KYC_VERIFICATIONS,
                Constants.RateLimits.ENTERPRISE_TRANSFER_HOOKS,
                Constants.RateLimits.ENTERPRISE_BADGE_VALIDATIONS,
                Constants.RateLimits.ENTERPRISE_AUDIT_LOGS
            )
            else -> TierLimits(
                Constants.RateLimits.FREE_KYC_VERIFICATIONS,
                Constants.RateLimits.FREE_TRANSFER_HOOKS,
                Constants.RateLimits.FREE_BADGE_VALIDATIONS,
                Constants.RateLimits.FREE_AUDIT_LOGS
            )
        }
    }
    
    /**
     * Get next billing reset date
     */
    private fun getNextResetDate(): Long {
        // In production, calculate based on billing cycle
        val calendar = java.util.Calendar.getInstance()
        calendar.add(java.util.Calendar.MONTH, 1)
        calendar.set(java.util.Calendar.DAY_OF_MONTH, 1)
        return calendar.timeInMillis
    }
    
    /**
     * Reset usage counters (for new billing period)
     */
    suspend fun resetUsageCounters() = withContext(Dispatchers.IO) {
        secureKeyStore.storeApiUsageCount("kyc_verification", 0)
        secureKeyStore.storeApiUsageCount("transfer_hook", 0)
        secureKeyStore.storeApiUsageCount("badge_validation", 0)
        secureKeyStore.storeApiUsageCount("audit_log", 0)
    }
    
    /**
     * Get usage percentage for a specific API type
     */
    suspend fun getUsagePercentage(type: String): Int = withContext(Dispatchers.IO) {
        val usage = getCurrentUsage()
        val used = when (type) {
            "kyc_verification" -> usage.kycVerificationsUsed
            "transfer_hook" -> usage.transferHooksUsed
            "badge_validation" -> usage.badgeValidationsUsed
            "audit_log" -> usage.auditLogsUsed
            else -> 0
        }
        val limit = when (type) {
            "kyc_verification" -> usage.kycVerificationsLimit
            "transfer_hook" -> usage.transferHooksLimit
            "badge_validation" -> usage.badgeValidationsLimit
            "audit_log" -> usage.auditLogsLimit
            else -> 0
        }
        
        if (limit == -1) return@withContext 0 // Unlimited
        if (limit == 0) return@withContext 100
        
        (used * 100) / limit
    }
}
