package com.example.kycapp.data.repositories

import android.content.Context
import com.example.kycapp.data.local.SecureKeyStore
import com.example.kycapp.domain.models.*
import com.example.kycapp.service.KycService
import com.example.kycapp.service.ZkProofService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * KycRepository - Handles KYC-related data operations
 */
class KycRepository(context: Context) {
    
    private val kycService = KycService(context)
    private val zkProofService = ZkProofService(context)
    private val secureKeyStore = SecureKeyStore(context)
    
    /**
     * Start KYC enrollment
     */
    suspend fun startKycEnrollment(
        walletId: String,
        personalInfo: PersonalInfo
    ): KycProofResult = withContext(Dispatchers.IO) {
        kycService.startKycEnrollment(walletId, personalInfo)
    }
    
    /**
     * Submit KYC proof
     */
    suspend fun submitKycProof(walletId: String): KycProofResult = withContext(Dispatchers.IO) {
        kycService.submitKycProof(walletId)
    }
    
    /**
     * Check KYC status
     */
    suspend fun checkKycStatus(walletId: String): KycStatus = withContext(Dispatchers.IO) {
        kycService.checkKycStatus(walletId)
    }
    
    /**
     * Get KYC proof
     */
    suspend fun getKycProof(walletId: String): KycProof? = withContext(Dispatchers.IO) {
        kycService.getKycProof(walletId)
    }
    
    /**
     * Revoke KYC proof
     */
    suspend fun revokeKycProof(walletId: String): Boolean = withContext(Dispatchers.IO) {
        kycService.revokeKycProof(walletId)
    }
    
    /**
     * Refresh KYC proof
     */
    suspend fun refreshKycProof(walletId: String): KycProofResult = withContext(Dispatchers.IO) {
        kycService.refreshKycProof(walletId)
    }
    
    /**
     * Verify KYC proof
     */
    suspend fun verifyKycProof(proof: KycProof): Boolean = withContext(Dispatchers.IO) {
        zkProofService.verifyKycProof(proof)
    }
    
    /**
     * Generate badge proof
     */
    suspend fun generateBadgeProof(
        walletId: String,
        badgeType: BadgeType
    ): KycProofResult = withContext(Dispatchers.IO) {
        zkProofService.generateBadgeProof(walletId, badgeType)
    }
    
    /**
     * Get current membership tier
     */
    suspend fun getMembershipTier(): String = withContext(Dispatchers.IO) {
        secureKeyStore.getMembershipTier()
    }
}
