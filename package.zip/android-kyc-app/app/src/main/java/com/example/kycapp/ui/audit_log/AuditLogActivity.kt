package com.example.kycapp.ui.audit_log

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.kycapp.databinding.ActivityAuditLogBinding

/**
 * AuditLogActivity - Displays compliance audit log history
 */
class AuditLogActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityAuditLogBinding
    private val viewModel: AuditLogViewModel by viewModels()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAuditLogBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupUI()
        observeViewModel()
        loadData()
    }
    
    private fun setupUI() {
        binding.toolbar.setNavigationOnClickListener {
            finish()
        }
        
        binding.btnExport.setOnClickListener {
            viewModel.exportAuditLogs("default_wallet")
        }
    }
    
    private fun loadData() {
        viewModel.loadAuditLogs("default_wallet")
    }
    
    private fun observeViewModel() {
        viewModel.auditLogs.observe(this) { logs ->
            if (logs.isEmpty()) {
                binding.tvNoLogs.visibility = android.view.View.VISIBLE
                binding.rvLogs.visibility = android.view.View.GONE
            } else {
                binding.tvNoLogs.visibility = android.view.View.GONE
                binding.rvLogs.visibility = android.view.View.VISIBLE
                // In production, setup RecyclerView adapter
                binding.tvLogsContent.text = logs.joinToString("\n\n") { log ->
                    "${log.action}: ${log.details} (${log.status})"
                }
            }
        }
        
        viewModel.isLoading.observe(this) { isLoading ->
            binding.progressBar.visibility = if (isLoading) android.view.View.VISIBLE else android.view.View.GONE
        }
        
        viewModel.exportResult.observe(this) { result ->
            result?.let {
                if (it) {
                    Toast.makeText(this, "Audit log exported successfully", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Export failed", Toast.LENGTH_SHORT).show()
                }
                viewModel.clearExportResult()
            }
        }
    }
}
