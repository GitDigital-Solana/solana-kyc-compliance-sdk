package com.example.kycapp.service

import android.content.Context
import com.example.kycapp.data.local.SecureKeyStore
import com.example.kycapp.data.remote.ComplianceBackendApi
import com.example.kycapp.data.remote.models.KycProofRequest
import com.example.kycapp.domain.models.*
import com.example.kycapp.util.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * KycService - Orchestrates KYC process, proof generation, and submission
 */
class KycService(context: Context) {
    
    private val secureKeyStore = SecureKeyStore(context)
    private val zkProofService = ZkProofService(context)
    private val complianceBackendApi = ComplianceBackendApi()
    
    /**
     * Start KYC enrollment process
     */
    suspend fun startKycEnrollment(
        walletId: String,
        personalInfo: PersonalInfo
    ): KycProofResult = withContext(Dispatchers.IO) {
        try {
            // Generate zk proof
            val proofResult = zkProofService.generateKycProof(walletId, personalInfo)
            
            when (proofResult) {
                is KycProofResult.Success -> {
                    // Store proof locally
                    secureKeyStore.storeKycProof(walletId, proofResult.proof.proofData)
                    proofResult
                }
                is KycProofResult.Error -> proofResult
                is KycProofResult.InProgress -> KycProofResult.InProgress
            }
        } catch (e: Exception) {
            KycProofResult.Error(
                e.message ?: "Failed to start KYC enrollment",
                Constants.ERROR_INVALID_KYC
            )
        }
    }
    
    /**
     * Submit KYC proof to compliance registry
     */
    suspend fun submitKycProof(walletId: String): KycProofResult = withContext(Dispatchers.IO) {
        try {
            // Retrieve stored proof
            val proofData = secureKeyStore.getKycProof(walletId)
                ?: return@withContext KycProofResult.Error(
                    "No KYC proof found. Please generate proof first.",
                    Constants.ERROR_INVALID_KYC
                )
            
            // Create request
            val request = KycProofRequest(
                walletId = walletId,
                personalInfo = PersonalInfo(
                    fullName = "",
                    dateOfBirth = "",
                    nationality = "",
                    documentType = "",
                    documentNumber = ""
                ),
                verificationData = mapOf("proof" to proofData)
            )
            
            // Submit to backend
            val response = complianceBackendApi.submitKycProof(request)
            
            if (response.isSuccessful) {
                val proof = KycProof(
                    proofId = response.body()?.proofId ?: "",
                    walletId = walletId,
                    proofData = proofData,
                    publicSignals = emptyList(),
                    circuitId = "kyc_circuit_v1",
                    createdAt = System.currentTimeMillis(),
                    expiresAt = System.currentTimeMillis() + (Constants.KYC_PROOF_VALIDITY_DAYS * 24 * 60 * 60 * 1000L)
                )
                KycProofResult.Success(proof)
            } else {
                KycProofResult.Error(
                    "Failed to submit KYC proof: ${response.message()}",
                    Constants.ERROR_INVALID_KYC
                )
            }
        } catch (e: Exception) {
            KycProofResult.Error(
                e.message ?: "Error submitting KYC proof",
                Constants.ERROR_NETWORK
            )
        }
    }
    
    /**
     * Check KYC status
     */
    suspend fun checkKycStatus(walletId: String): KycStatus = withContext(Dispatchers.IO) {
        try {
            val response = complianceBackendApi.getComplianceStatus(walletId)
            if (response.isSuccessful) {
                response.body()?.kycStatus ?: KycStatus.NOT_STARTED
            } else {
                KycStatus.NOT_STARTED
            }
        } catch (e: Exception) {
            // Check local proof expiry
            val proofData = secureKeyStore.getKycProof(walletId)
            if (proofData != null) {
                KycStatus.VERIFIED
            } else {
                KycStatus.NOT_STARTED
            }
        }
    }
    
    /**
     * Get KYC proof for wallet
     */
    suspend fun getKycProof(walletId: String): KycProof? = withContext(Dispatchers.IO) {
        try {
            val proofData = secureKeyStore.getKycProof(walletId) ?: return@withContext null
            
            KycProof(
                proofId = "proof_$walletId",
                walletId = walletId,
                proofData = proofData,
                publicSignals = emptyList(),
                circuitId = "kyc_circuit_v1",
                createdAt = System.currentTimeMillis(),
                expiresAt = System.currentTimeMillis() + (Constants.KYC_PROOF_VALIDITY_DAYS * 24 * 60 * 60 * 1000L)
            )
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * Revoke KYC proof (if user wants to reset)
     */
    suspend fun revokeKycProof(walletId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            secureKeyStore.deleteWalletKeys(walletId)
            true
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * Refresh KYC proof before expiry
     */
    suspend fun refreshKycProof(walletId: String): KycProofResult = withContext(Dispatchers.IO) {
        try {
            // Delete old proof
            secureKeyStore.deleteWalletKeys(walletId)
            
            // Generate new proof with stored personal info (would need to retrieve from secure storage)
            val personalInfo = PersonalInfo(
                fullName = "",
                dateOfBirth = "",
                nationality = "",
                documentType = "",
                documentNumber = ""
            )
            
            startKycEnrollment(walletId, personalInfo)
        } catch (e: Exception) {
            KycProofResult.Error(
                e.message ?: "Failed to refresh KYC proof",
                Constants.ERROR_INVALID_KYC
            )
        }
    }
}
