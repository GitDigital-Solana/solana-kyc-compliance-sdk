package com.example.kycapp.ui.kyc

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kycapp.application.KycApplication
import com.example.kycapp.domain.models.KycProofResult
import com.example.kycapp.domain.models.KycStatus
import com.example.kycapp.domain.models.PersonalInfo
import kotlinx.coroutines.launch

/**
 * KycViewModel - Handles KYC verification logic
 */
class KycViewModel : ViewModel() {
    
    private val kycRepository = KycApplication.instance.kycRepository
    
    // UI State
    private val _kycState = MutableLiveData<KycUiState>()
    val kycState: LiveData<KycUiState> = _kycState
    
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading
    
    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> = _errorMessage
    
    private var currentWalletId: String? = null
    
    /**
     * Set wallet ID for KYC
     */
    fun setWalletId(walletId: String) {
        currentWalletId = walletId
        checkKycStatus(walletId)
    }
    
    /**
     * Check KYC status
     */
    fun checkKycStatus(walletId: String) {
        viewModelScope.launch {
            val status = kycRepository.checkKycStatus(walletId)
            _kycState.value = when (status) {
                KycStatus.VERIFIED -> KycUiState.Verified
                KycStatus.IN_PROGRESS -> KycUiState.InProgress
                KycStatus.PENDING_VERIFICATION -> KycUiState.Pending
                KycStatus.REJECTED -> KycUiState.Rejected
                KycStatus.EXPIRED -> KycUiState.Expired
                KycStatus.NOT_STARTED -> KycUiState.NotStarted
            }
        }
    }
    
    /**
     * Start KYC verification
     */
    fun startKycVerification(personalInfo: PersonalInfo) {
        val walletId = currentWalletId ?: return
        
        _isLoading.value = true
        _errorMessage.value = null
        
        viewModelScope.launch {
            val result = kycRepository.startKycEnrollment(walletId, personalInfo)
            
            _isLoading.value = false
            
            when (result) {
                is KycProofResult.Success -> {
                    _kycState.value = KycUiState.InProgress
                    // Submit proof to backend
                    submitProof(walletId)
                }
                is KycProofResult.Error -> {
                    _kycState.value = KycUiState.Error(result.message)
                    _errorMessage.value = result.message
                }
                is KycProofResult.InProgress -> {
                    _kycState.value = KycUiState.InProgress
                }
            }
        }
    }
    
    /**
     * Submit KYC proof to backend
     */
    private fun submitProof(walletId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            
            val result = kycRepository.submitKycProof(walletId)
            
            _isLoading.value = false
            
            when (result) {
                is KycProofResult.Success -> {
                    _kycState.value = KycUiState.Pending
                }
                is KycProofResult.Error -> {
                    _kycState.value = KycUiState.Error(result.message)
                    _errorMessage.value = result.message
                }
                else -> {}
            }
        }
    }
    
    /**
     * Clear error message
     */
    fun clearError() {
        _errorMessage.value = null
    }
}

/**
 * KYC UI State
 */
sealed class KycUiState {
    object NotStarted : KycUiState()
    object InProgress : KycUiState()
    object Pending : KycUiState()
    object Verified : KycUiState()
    object Rejected : KycUiState()
    object Expired : KycUiState()
    data class Error(val message: String) : KycUiState()
}
