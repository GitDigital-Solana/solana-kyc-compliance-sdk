package com.example.kycapp.ui.compliance_status

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kycapp.application.KycApplication
import com.example.kycapp.domain.models.BadgeType
import com.example.kycapp.domain.models.ComplianceBadge
import com.example.kycapp.domain.models.ComplianceStatusResponse
import com.example.kycapp.domain.models.KycStatus
import kotlinx.coroutines.launch

/**
 * ComplianceStatusViewModel - Displays KYC compliance status and badges
 */
class ComplianceStatusViewModel : ViewModel() {
    
    private val complianceRepository = KycApplication.instance.complianceRepository
    
    private val _complianceStatus = MutableLiveData<ComplianceStatusResponse?>()
    val complianceStatus: LiveData<ComplianceStatusResponse?> = _complianceStatus
    
    private val _badge = MutableLiveData<ComplianceBadge?>()
    val badge: LiveData<ComplianceBadge?> = _badge
    
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading
    
    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> = _errorMessage
    
    /**
     * Load compliance status
     */
    fun loadComplianceStatus(walletId: String) {
        _isLoading.value = true
        
        viewModelScope.launch {
            try {
                val status = complianceRepository.getComplianceStatus(walletId)
                _complianceStatus.value = status
                _badge.value = status.badge
            } catch (e: Exception) {
                _errorMessage.value = e.message
            } finally {
                _isLoading.value = false
            }
        }
    }
    
    /**
     * Verify badge
     */
    fun verifyBadge(walletId: String) {
        viewModelScope.launch {
            val result = complianceRepository.validateBadge(walletId)
            when (result) {
                is com.example.kycapp.domain.models.BadgeValidationResult.Valid -> {
                    _badge.value = result.badge
                }
                is com.example.kycapp.domain.models.BadgeValidationResult.Invalid -> {
                    _errorMessage.value = result.reason
                }
                is com.example.kycapp.domain.models.BadgeValidationResult.NotFound -> {
                    _errorMessage.value = "Badge not found"
                }
            }
        }
    }
    
    /**
     * Request badge upgrade
     */
    fun requestBadgeUpgrade(walletId: String, badgeType: BadgeType) {
        viewModelScope.launch {
            val result = complianceRepository.requestBadge(walletId, badgeType)
            result.onSuccess { badge ->
                _badge.value = badge
            }.onFailure { error ->
                _errorMessage.value = error.message
            }
        }
    }
    
    /**
     * Clear error
     */
    fun clearError() {
        _errorMessage.value = null
    }
}
