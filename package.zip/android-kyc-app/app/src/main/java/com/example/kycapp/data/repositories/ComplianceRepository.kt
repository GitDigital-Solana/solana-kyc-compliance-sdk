package com.example.kycapp.data.repositories

import android.content.Context
import com.example.kycapp.domain.models.*
import com.example.kycapp.service.BadgeValidationClient
import com.example.kycapp.service.BillingEngine
import com.example.kycapp.service.ComplianceRegistryClient
import com.example.kycapp.service.TransferHookEnforcer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * ComplianceRepository - Manages compliance status data
 */
class ComplianceRepository(context: Context) {
    
    private val complianceRegistryClient = ComplianceRegistryClient(context)
    private val badgeValidationClient = BadgeValidationClient(context)
    private val transferHookEnforcer = TransferHookEnforcer(context)
    private val billingEngine = BillingEngine(context)
    
    /**
     * Get compliance status
     */
    suspend fun getComplianceStatus(walletId: String): ComplianceStatusResponse = withContext(Dispatchers.IO) {
        complianceRegistryClient.getComplianceStatus(walletId)
    }
    
    /**
     * Register compliance badge
     */
    suspend fun registerComplianceBadge(badge: ComplianceBadge): Boolean = withContext(Dispatchers.IO) {
        complianceRegistryClient.registerComplianceBadge(badge)
    }
    
    /**
     * Verify badge on-chain
     */
    suspend fun verifyBadgeOnChain(walletId: String): BadgeValidationResult = withContext(Dispatchers.IO) {
        badgeValidationClient.validateBadge(walletId)
    }
    
    /**
     * Validate badge
     */
    suspend fun validateBadge(
        walletId: String,
        requiredBadgeType: BadgeType? = null
    ): BadgeValidationResult = withContext(Dispatchers.IO) {
        badgeValidationClient.validateBadge(walletId, requiredBadgeType)
    }
    
    /**
     * Request badge
     */
    suspend fun requestBadge(
        walletId: String,
        badgeType: BadgeType
    ): Result<ComplianceBadge> = withContext(Dispatchers.IO) {
        badgeValidationClient.requestBadge(walletId, badgeType)
    }
    
    /**
     * Get all wallet badges
     */
    suspend fun getWalletBadges(walletId: String): List<ComplianceBadge> = withContext(Dispatchers.IO) {
        badgeValidationClient.getWalletBadges(walletId)
    }
    
    /**
     * Validate transfer
     */
    suspend fun validateTransfer(
        sourceWalletId: String,
        destWalletId: String,
        amount: Double
    ): TransferHookEnforcer.TransferHookResult = withContext(Dispatchers.IO) {
        transferHookEnforcer.validateTransfer(sourceWalletId, destWalletId, amount)
    }
    
    /**
     * Get transfer restrictions
     */
    suspend fun getTransferRestrictions(walletId: String): List<String> = withContext(Dispatchers.IO) {
        transferHookEnforcer.getTransferRestrictions(walletId)
    }
    
    /**
     * Get current usage
     */
    suspend fun getCurrentUsage(): BillingEngine.UsageInfo = withContext(Dispatchers.IO) {
        billingEngine.getCurrentUsage()
    }
    
    /**
     * Get membership tiers
     */
    fun getMembershipTiers(): List<BillingEngine.MembershipTier> = withContext(Dispatchers.IO) {
        billingEngine.getMembershipTiers()
    }
    
    /**
     * Upgrade tier
     */
    suspend fun upgradeTier(newTier: String): Boolean = withContext(Dispatchers.IO) {
        billingEngine.upgradeTier(newTier)
    }
    
    /**
     * Check API call availability
     */
    suspend fun canMakeApiCall(type: String): Boolean = withContext(Dispatchers.IO) {
        billingEngine.canMakeApiCall(type)
    }
    
    /**
     * Record API call
     */
    suspend fun recordApiCall(type: String): Int = withContext(Dispatchers.IO) {
        billingEngine.recordApiCall(type)
    }
    
    /**
     * Submit audit log
     */
    suspend fun submitAuditLog(
        walletId: String,
        action: String,
        details: Map<String, String>
    ): Boolean = withContext(Dispatchers.IO) {
        complianceRegistryClient.submitAuditLog(walletId, action, details)
    }
}
