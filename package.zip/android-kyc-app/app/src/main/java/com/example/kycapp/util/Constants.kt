package com.example.kycapp.util

/**
 * Application constants for zk-Solana KYC Compliance App
 */
object Constants {
    
    // Backend API Configuration
    const val BASE_URL = "https://api.compliance-registry.devnet.solana.com/"
    const val API_VERSION = "v1"
    const val TIMEOUT_SECONDS = 30L
    
    // Solana Configuration
    const val SOLANA_NETWORK = "devnet"
    const val SOLANA_RPC_URL = "https://api.devnet.solana.com"
    
    // KYC Configuration
    const val KYC_PROOF_VALIDITY_DAYS = 365
    const val MAX_KYC_RETRY_ATTEMPTS = 3
    const val KYC_VERIFICATION_TIMEOUT_MS = 60000L
    
    // Wallet Configuration
    const val WALLET_NAME_PREFIX = "zkKycWallet_"
    const val MIN_BALANCE_FOR_TRANSACTIONS = 0.001 // SOL
    
    // Membership Tiers
    const val TIER_FREE = "free"
    const val TIER_BASIC = "basic"
    const val TIER_PRO = "pro"
    const val TIER_ENTERPRISE = "enterprise"
    
    // API Rate Limits by Tier
    object RateLimits {
        const val FREE_KYC_VERIFICATIONS = 10
        const val FREE_TRANSFER_HOOKS = 50
        const val FREE_BADGE_VALIDATIONS = 100
        const val FREE_AUDIT_LOGS = 5
        
        const val BASIC_KYC_VERIFICATIONS = 50
        const val BASIC_TRANSFER_HOOKS = 250
        const val BASIC_BADGE_VALIDATIONS = 500
        const val BASIC_AUDIT_LOGS = 50
        
        const val PRO_KYC_VERIFICATIONS = 200
        const val PRO_TRANSFER_HOOKS = 1000
        const val PRO_BADGE_VALIDATIONS = 2000
        const val PRO_AUDIT_LOGS = 200
        
        const val ENTERPRISE_KYC_VERIFICATIONS = -1 // Unlimited
        const val ENTERPRISE_TRANSFER_HOOKS = -1
        const val ENTERPRISE_BADGE_VALIDATIONS = -1
        const val ENTERPRISE_AUDIT_LOGS = -1
    }
    
    // Security Configuration
    const val KEYSTORE_ALIAS = "zkKycKeyStore"
    const val ENCRYPTED_PREFS_NAME = "zkKycSecurePrefs"
    const val BIOMETRIC_AUTH_ENABLED = true
    
    // Compliance Badge Types
    const val BADGE_TYPE_BASIC = "basic_kyc"
    const val BADGE_TYPE_ADVANCED = "advanced_kyc"
    const val BADGE_TYPE_GOVERNANCE = "governance_grade"
    
    // Transfer Hook Configuration
    const val TRANSFER_HOOK_PROGRAM_ID = "TransferHook11111111111111111111111111"
    const val MIN_TRANSFER_AMOUNT = 0.001
    
    // Metering Configuration
    const val METERING_ENABLED = true
    const val METERING_REPORT_INTERVAL_HOURS = 24
    
    // Error Codes
    const val ERROR_NETWORK = "NETWORK_ERROR"
    const val ERROR_INVALID_KYC = "INVALID_KYC"
    const val ERROR_WALLET_NOT_FOUND = "WALLET_NOT_FOUND"
    const val ERROR_COMPLIANCE_FAILED = "COMPLIANCE_FAILED"
    const val ERROR_RATE_LIMIT_EXCEEDED = "RATE_LIMIT_EXCEEDED"
    const val ERROR_BIOMETRIC_FAILED = "BIOMETRIC_FAILED"
}
