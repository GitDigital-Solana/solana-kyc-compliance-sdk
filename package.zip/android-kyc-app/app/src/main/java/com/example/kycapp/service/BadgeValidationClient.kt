package com.example.kycapp.service

import android.content.Context
import com.example.kycapp.data.local.SecureKeyStore
import com.example.kycapp.data.remote.ComplianceBackendApi
import com.example.kycapp.domain.models.BadgeType
import com.example.kycapp.domain.models.BadgeValidationResult
import com.example.kycapp.domain.models.ComplianceBadge
import com.example.kycapp.util.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * BadgeValidationClient - Validates compliance badges with backend
 */
class BadgeValidationClient(context: Context) {
    
    private val secureKeyStore = SecureKeyStore(context)
    private val complianceBackendApi = ComplianceBackendApi()
    
    /**
     * Validate badge for wallet
     */
    suspend fun validateBadge(
        walletId: String,
        requiredBadgeType: BadgeType? = null
    ): BadgeValidationResult = withContext(Dispatchers.IO) {
        try {
            // Check API usage limits
            val usageCount = secureKeyStore.incrementApiUsageCount("badge_validation")
            val tier = secureKeyStore.getMembershipTier()
            val limit = getBadgeValidationLimit(tier)
            
            if (limit != -1 && usageCount > limit) {
                return@withContext BadgeValidationResult.Invalid("API rate limit exceeded")
            }
            
            // Try to get badge from backend
            val response = complianceBackendApi.verifyBadge(walletId)
            
            if (response.isSuccessful && response.body() != null) {
                val badgeResponse = response.body()!!
                val badge = ComplianceBadge(
                    badgeId = badgeResponse.badgeId,
                    walletId = walletId,
                    badgeType = BadgeType.fromString(badgeResponse.badgeType),
                    issuedAt = badgeResponse.issuedAt,
                    expiresAt = badgeResponse.expiresAt,
                    issuer = badgeResponse.issuer
                )
                
                // Check if badge is valid
                if (!badge.isValid()) {
                    return@withContext BadgeValidationResult.Invalid("Badge is expired or revoked")
                }
                
                // Check if badge meets requirement
                val meetsRequirement = requiredBadgeType?.let {
                    badge.badgeType.level >= it.level
                } ?: true
                
                BadgeValidationResult.Valid(badge, meetsRequirement)
            } else {
                BadgeValidationResult.NotFound
            }
        } catch (e: Exception) {
            BadgeValidationResult.Invalid("Validation failed: ${e.message}")
        }
    }
    
    /**
     * Request new badge issuance
     */
    suspend fun requestBadge(
        walletId: String,
        badgeType: BadgeType
    ): Result<ComplianceBadge> = withContext(Dispatchers.IO) {
        try {
            // Check if wallet is eligible for badge
            val currentBadge = validateBadge(walletId)
            
            val meetsRequirement = when (currentBadge) {
                is BadgeValidationResult.Valid -> {
                    currentBadge.badge.badgeType.level >= badgeType.level
                }
                else -> badgeType == BadgeType.BASIC_KYC
            }
            
            if (!meetsRequirement) {
                return@withContext Result.failure(
                    Exception("Wallet does not meet requirements for ${badgeType.displayName}")
                )
            }
            
            // Request badge from backend
            val response = complianceBackendApi.requestBadge(
                walletId = walletId,
                badgeType = badgeType.name
            )
            
            if (response.isSuccessful && response.body() != null) {
                val badgeResponse = response.body()!!
                val badge = ComplianceBadge(
                    badgeId = badgeResponse.badgeId,
                    walletId = walletId,
                    badgeType = badgeType,
                    issuedAt = badgeResponse.issuedAt,
                    expiresAt = badgeResponse.expiresAt,
                    issuer = badgeResponse.issuer
                )
                
                // Store locally
                secureKeyStore.storeComplianceBadge(walletId, badge.badgeId)
                
                Result.success(badge)
            } else {
                Result.failure(Exception("Failed to request badge"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Get all badges for wallet
     */
    suspend fun getWalletBadges(walletId: String): List<ComplianceBadge> = withContext(Dispatchers.IO) {
        try {
            val response = complianceBackendApi.getWalletBadges(walletId)
            if (response.isSuccessful && response.body() != null) {
                response.body()!!.map { badgeResponse ->
                    ComplianceBadge(
                        badgeId = badgeResponse.badgeId,
                        walletId = walletId,
                        badgeType = BadgeType.fromString(badgeResponse.badgeType),
                        issuedAt = badgeResponse.issuedAt,
                        expiresAt = badgeResponse.expiresAt,
                        issuer = badgeResponse.issuer
                    )
                }
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    /**
     * Revoke badge
     */
    suspend fun revokeBadge(walletId: String, badgeId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val response = complianceBackendApi.revokeBadge(walletId, badgeId)
            if (response.isSuccessful) {
                // Clear local storage
                secureKeyStore.storeComplianceBadge(walletId, "")
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * Check badge requirements
     */
    suspend fun checkBadgeRequirements(walletId: String): Map<BadgeType, Boolean> = withContext(Dispatchers.IO) {
        val currentBadge = validateBadge(walletId)
        val currentLevel = when (currentBadge) {
            is BadgeValidationResult.Valid -> currentBadge.badge.badgeType.level
            else -> 0
        }
        
        mapOf(
            BadgeType.BASIC_KYC to currentLevel >= BadgeType.BASIC_KYC.level,
            BadgeType.ADVANCED_KYC to currentLevel >= BadgeType.ADVANCED_KYC.level,
            BadgeType.GOVERNANCE_GRADE to currentLevel >= BadgeType.GOVERNANCE_GRADE.level
        )
    }
    
    /**
     * Get badge validation limit for membership tier
     */
    private fun getBadgeValidationLimit(tier: String): Int = when (tier) {
        Constants.TIER_FREE -> Constants.RateLimits.FREE_BADGE_VALIDATIONS
        Constants.TIER_BASIC -> Constants.RateLimits.BASIC_BADGE_VALIDATIONS
        Constants.TIER_PRO -> Constants.RateLimits.PRO_BADGE_VALIDATIONS
        Constants.TIER_ENTERPRISE -> Constants.RateLimits.ENTERPRISE_BADGE_VALIDATIONS
        else -> Constants.RateLimits.FREE_BADGE_VALIDATIONS
    }
}
