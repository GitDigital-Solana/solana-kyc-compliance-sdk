package com.example.kycapp.data.local

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.example.kycapp.util.Constants
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * SecureKeyStore - Handles secure storage of cryptographic keys and sensitive data
 * using Android Keystore and EncryptedSharedPreferences
 */
class SecureKeyStore(private val context: Context) {
    
    private val keyStore: KeyStore = KeyStore.getInstance("AndroidKeyStore").apply {
        load(null)
    }
    
    private val masterKey: MasterKey by lazy {
        MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
    }
    
    private val encryptedPrefs by lazy {
        EncryptedSharedPreferences.create(
            context,
            Constants.ENCRYPTED_PREFS_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }
    
    /**
     * Generate and store a new key pair for wallet operations
     */
    suspend fun generateWalletKey(walletId: String): Pair<String, String>? = withContext(Dispatchers.IO) {
        try {
            val keyGenerator = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES,
                Constants.KEYSTORE_ALIAS
            )
            
            val keyGenSpec = KeyGenParameterSpec.Builder(
                Constants.KEYSTORE_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
            
            keyGenerator.init(keyGenSpec)
            keyGenerator.generateKey()
            
            // Generate mock public/private key pair (in production, use proper Solana key generation)
            val publicKey = Base64.encodeToString(
                ("public_" + walletId).toByteArray(),
                Base64.NO_WRAP
            )
            val privateKey = Base64.encodeToString(
                ("private_" + walletId + "_" + System.currentTimeMillis()).toByteArray(),
                Base64.NO_WRAP
            )
            
            // Store keys securely
            storeWalletKeys(walletId, publicKey, privateKey)
            
            Pair(publicKey, privateKey)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
    
    /**
     * Store wallet keys in encrypted preferences
     */
    private fun storeWalletKeys(walletId: String, publicKey: String, privateKey: String) {
        encryptedPrefs.edit()
            .putString("wallet_${walletId}_public_key", publicKey)
            .putString("wallet_${walletId}_private_key", privateKey)
            .apply()
    }
    
    /**
     * Retrieve wallet public key
     */
    suspend fun getWalletPublicKey(walletId: String): String? = withContext(Dispatchers.IO) {
        encryptedPrefs.getString("wallet_${walletId}_public_key", null)
    }
    
    /**
     * Retrieve wallet private key (should be used only when necessary)
     */
    suspend fun getWalletPrivateKey(walletId: String): String? = withContext(Dispatchers.IO) {
        encryptedPrefs.getString("wallet_${walletId}_private_key", null)
    }
    
    /**
     * Store KYC proof data securely
     */
    suspend fun storeKycProof(walletId: String, proofData: String) = withContext(Dispatchers.IO) {
        encryptedPrefs.edit()
            .putString("kyc_proof_${walletId}", proofData)
            .apply()
    }
    
    /**
     * Retrieve KYC proof data
     */
    suspend fun getKycProof(walletId: String): String? = withContext(Dispatchers.IO) {
        encryptedPrefs.getString("kyc_proof_${walletId}", null)
    }
    
    /**
     * Store compliance badge data
     */
    suspend fun storeComplianceBadge(walletId: String, badgeData: String) = withContext(Dispatchers.IO) {
        encryptedPrefs.edit()
            .putString("compliance_badge_${walletId}", badgeData)
            .apply()
    }
    
    /**
     * Retrieve compliance badge data
     */
    suspend fun getComplianceBadge(walletId: String): String? = withContext(Dispatchers.IO) {
        encryptedPrefs.getString("compliance_badge_${walletId}", null)
    }
    
    /**
     * Store user session token
     */
    suspend fun storeSessionToken(token: String) = withContext(Dispatchers.IO) {
        encryptedPrefs.edit()
            .putString("session_token", token)
            .apply()
    }
    
    /**
     * Retrieve session token
     */
    suspend fun getSessionToken(): String? = withContext(Dispatchers.IO) {
        encryptedPrefs.getString("session_token", null)
    }
    
    /**
     * Clear all secure storage (for logout or data reset)
     */
    suspend fun clearAll() = withContext(Dispatchers.IO) {
        encryptedPrefs.edit().clear().apply()
    }
    
    /**
     * Delete specific wallet keys
     */
    suspend fun deleteWalletKeys(walletId: String) = withContext(Dispatchers.IO) {
        encryptedPrefs.edit()
            .remove("wallet_${walletId}_public_key")
            .remove("wallet_${walletId}_private_key")
            .remove("kyc_proof_${walletId}")
            .remove("compliance_badge_${walletId}")
            .apply()
    }
    
    /**
     * Check if wallet exists
     */
    suspend fun walletExists(walletId: String): Boolean = withContext(Dispatchers.IO) {
        encryptedPrefs.contains("wallet_${walletId}_public_key")
    }
    
    /**
     * Store membership tier information
     */
    suspend fun storeMembershipTier(tier: String) = withContext(Dispatchers.IO) {
        encryptedPrefs.edit()
            .putString("membership_tier", tier)
            .apply()
    }
    
    /**
     * Get membership tier
     */
    suspend fun getMembershipTier(): String = withContext(Dispatchers.IO) {
        encryptedPrefs.getString("membership_tier", Constants.TIER_FREE) ?: Constants.TIER_FREE
    }
    
    /**
     * Store API usage counts
     */
    suspend fun storeApiUsageCount(type: String, count: Int) = withContext(Dispatchers.IO) {
        encryptedPrefs.edit()
            .putInt("api_usage_${type}", count)
            .apply()
    }
    
    /**
     * Get API usage count
     */
    suspend fun getApiUsageCount(type: String): Int = withContext(Dispatchers.IO) {
        encryptedPrefs.getInt("api_usage_${type}", 0)
    }
    
    /**
     * Increment and get API usage count
     */
    suspend fun incrementApiUsageCount(type: String): Int = withContext(Dispatchers.IO) {
        val currentCount = getApiUsageCount(type)
        val newCount = currentCount + 1
        storeApiUsageCount(type, newCount)
        newCount
    }
}
