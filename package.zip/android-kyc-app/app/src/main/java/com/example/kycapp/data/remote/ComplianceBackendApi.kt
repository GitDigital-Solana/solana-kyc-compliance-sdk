package com.example.kycapp.data.remote

import com.example.kycapp.data.remote.models.*
import com.example.kycapp.util.Constants
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

/**
 * ComplianceBackendApi - Retrofit interface for backend API communication
 */
class ComplianceBackendApi {
    
    private val retrofit: Retrofit by lazy {
        val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
        
        val client = OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .connectTimeout(Constants.TIMEOUT_SECONDS, TimeUnit.SECONDS)
            .readTimeout(Constants.TIMEOUT_SECONDS, TimeUnit.SECONDS)
            .writeTimeout(Constants.TIMEOUT_SECONDS, TimeUnit.SECONDS)
            .build()
        
        Retrofit.Builder()
            .baseUrl(Constants.BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }
    
    private val apiService: ApiService by lazy {
        retrofit.create(ApiService::class.java)
    }
    
    /**
     * Submit KYC proof to compliance registry
     */
    suspend fun submitKycProof(request: KycProofRequest): Response<KycProofResponse> {
        return apiService.submitKycProof(request)
    }
    
    /**
     * Get compliance status for wallet
     */
    suspend fun getComplianceStatus(walletId: String): Response<ComplianceStatusResponseDto> {
        return apiService.getComplianceStatus(walletId)
    }
    
    /**
     * Verify badge on-chain
     */
    suspend fun verifyBadge(walletId: String): Response<BadgeResponse> {
        return apiService.verifyBadge(walletId)
    }
    
    /**
     * Register new badge
     */
    suspend fun registerBadge(badge: com.example.kycapp.domain.models.ComplianceBadge): Response<BadgeResponse> {
        return apiService.registerBadge(
            RegisterBadgeRequest(
                walletId = badge.walletId,
                badgeType = badge.badgeType.name,
                metadata = badge.metadata
            )
        )
    }
    
    /**
     * Request badge issuance
     */
    suspend fun requestBadge(walletId: String, badgeType: String): Response<BadgeResponse> {
        return apiService.requestBadge(
            RequestBadgeRequest(
                walletId = walletId,
                badgeType = badgeType
            )
        )
    }
    
    /**
     * Get all badges for wallet
     */
    suspend fun getWalletBadges(walletId: String): Response<List<BadgeResponse>> {
        return apiService.getWalletBadges(walletId)
    }
    
    /**
     * Revoke badge
     */
    suspend fun revokeBadge(walletId: String, badgeId: String): Response<RevokeBadgeResponse> {
        return apiService.revokeBadge(
            RevokeBadgeRequest(
                walletId = walletId,
                badgeId = badgeId
            )
        )
    }
    
    /**
     * Update compliance status
     */
    suspend fun updateComplianceStatus(
        walletId: String,
        kycStatus: String,
        badgeId: String?
    ): Response<UpdateComplianceResponse> {
        return apiService.updateComplianceStatus(
            UpdateComplianceRequest(
                walletId = walletId,
                kycStatus = kycStatus,
                badgeId = badgeId
            )
        )
    }
    
    /**
     * Submit audit log
     */
    suspend fun submitAuditLog(
        walletId: String,
        action: String,
        details: Map<String, String>,
        timestamp: Long
    ): Response<AuditLogResponse> {
        return apiService.submitAuditLog(
            AuditLogRequest(
                walletId = walletId,
                action = action,
                details = details,
                timestamp = timestamp
            )
        )
    }
}

/**
 * API Service interface
 */
interface ApiService {
    
    @POST("api/v1/kyc/proof")
    suspend fun submitKycProof(@Body request: KycProofRequest): Response<KycProofResponse>
    
    @GET("api/v1/compliance/status/{walletId}")
    suspend fun getComplianceStatus(@Path("walletId") walletId: String): Response<ComplianceStatusResponseDto>
    
    @GET("api/v1/badges/verify/{walletId}")
    suspend fun verifyBadge(@Path("walletId") walletId: String): Response<BadgeResponse>
    
    @POST("api/v1/badges/register")
    suspend fun registerBadge(@Body request: RegisterBadgeRequest): Response<BadgeResponse>
    
    @POST("api/v1/badges/request")
    suspend fun requestBadge(@Body request: RequestBadgeRequest): Response<BadgeResponse>
    
    @GET("api/v1/badges/wallet/{walletId}")
    suspend fun getWalletBadges(@Path("walletId") walletId: String): Response<List<BadgeResponse>>
    
    @POST("api/v1/badges/revoke")
    suspend fun revokeBadge(@Body request: RevokeBadgeRequest): Response<RevokeBadgeResponse>
    
    @PUT("api/v1/compliance/status")
    suspend fun updateComplianceStatus(@Body request: UpdateComplianceRequest): Response<UpdateComplianceResponse>
    
    @POST("api/v1/audit/log")
    suspend fun submitAuditLog(@Body request: AuditLogRequest): Response<AuditLogResponse>
}
