# zk-Solana KYC Compliance Android Application

A production-ready Android application integrating a zk-Solana KYC Compliance SDK for zero-knowledge Know Your Customer (KYC) compliance on the Solana blockchain.

## Features

### Core Functionalities
- **Wallet and Identity Management**: Secure local wallet creation, key storage, client-side zk-KYC proof generation, proof submission to compliance registry, compliance status display
- **Compliance Enforcement**: Transfer hooks to block non-KYC compliant wallets, validation of compliance badges via backend API calls
- **Feature Tiers**:
  - **Free (Core)**: Basic features with limited API calls
  - **Basic**: Increased API call limits and access to more features
  - **Pro**: Higher limits, advanced features, and priority support
  - **Enterprise**: Custom limits, dedicated support, and access to all features

### Metering System
Tracks the following API calls and security features:
- **API Calls**: KYC Proof Verifications, Transfer-Hook Invocations, Badge Validation Checks, Audit Log Exports
- **Security Features**: Device Attestation Checks, Session Token Refreshes

## Tech Stack

| Component | Technology |
|-----------|------------|
| Platform | Android |
| Language | Kotlin |
| Blockchain | Solana (Devnet for testing) |
| SDK | zk-Solana KYC Compliance SDK |
| Backend | Serverless (Python Lambda) |

## Project Structure

```
android-kyc-app/
├── serverless_backend/
│   └── main.py                 # Python Lambda backend
├── app/
│   ├── build.gradle.kts        # App-level Gradle config
│   └── src/
│       └── main/
│           ├── AndroidManifest.xml
│           ├── java/com/example/kycapp/
│           │   ├── MainActivity.kt
│           │   ├── application/KycApplication.kt
│           │   ├── ui/
│           │   │   ├── MainActivity.kt
│           │   │   ├── onboarding/
│           │   │   ├── kyc/
│           │   │   ├── compliance_status/
│           │   │   ├── pricing_upgrade/
│           │   │   └── audit_log/
│           │   ├── data/
│           │   │   ├── local/SecureKeyStore.kt
│           │   │   ├── remote/ComplianceBackendApi.kt
│           │   │   └── repositories/
│           │   ├── domain/models/
│           │   ├── service/
│           │   └── util/Constants.kt
│           └── solana_sdk/ZkSolanaKycSdk.kt
├── build.gradle.kts            # Root Gradle config
├── settings.gradle.kts
└── gradlew
```

## Getting Started

### Prerequisites
- Android Studio Hedgehog or later
- Kotlin 1.9.20
- Android SDK 34
- Java 17

### Build Instructions

1. Clone the repository
2. Open the project in Android Studio
3. Sync Gradle files
4. Build and run on device or emulator

### Configuration

Update `Constants.kt` with your backend URL:
```kotlin
const val BASE_URL = "https://your-backend-url.amazonaws.com/"
const val SOLANA_RPC_URL = "https://api.devnet.solana.com"
```

## Architecture

The app follows Clean Architecture principles:

- **UI Layer**: Activities, ViewModels, XML layouts
- **Domain Layer**: Use cases, business models
- **Data Layer**: Repositories, API clients, local storage

## Security

- Keys stored in Android Keystore
- Sensitive data in EncryptedSharedPreferences
- Biometric authentication support
- No plaintext storage of private keys

## License

MIT License
